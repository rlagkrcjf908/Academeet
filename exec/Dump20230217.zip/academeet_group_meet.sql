-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: academeet.shop    Database: academeet
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `group_meet`
--

DROP TABLE IF EXISTS `group_meet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_meet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int DEFAULT NULL,
  `meet_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Meet_TO_Group_Meet_1` (`meet_id`),
  KEY `FK_Group_TO_Group_Meet_1` (`group_id`),
  CONSTRAINT `FK_Group_TO_Group_Meet_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `FK_Meet_TO_Group_Meet_1` FOREIGN KEY (`meet_id`) REFERENCES `meet` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_meet`
--

LOCK TABLES `group_meet` WRITE;
/*!40000 ALTER TABLE `group_meet` DISABLE KEYS */;
INSERT INTO `group_meet` VALUES (16,2,1),(18,9,3),(19,2,4),(20,1,5),(30,20,20),(33,25,28),(34,22,29),(35,20,30),(36,22,31),(37,22,32),(38,24,34),(39,20,36),(40,20,37),(41,24,38),(43,20,41),(44,22,42),(46,25,48),(47,20,51),(48,20,52),(49,20,53),(50,24,54),(51,35,62),(52,36,64),(54,42,73),(55,43,77),(56,32,78),(57,32,79),(58,44,80),(63,46,92),(64,46,93),(65,46,94),(68,32,97),(71,47,103),(72,52,104),(73,52,105),(74,52,106),(75,52,107),(76,52,108),(78,46,110),(79,52,111),(80,52,113),(81,52,114),(82,42,115),(83,42,116),(84,52,117),(85,52,118),(86,52,119),(87,52,120),(88,52,121),(89,52,122),(90,52,123),(91,52,124),(92,60,125),(93,52,126),(94,52,127),(95,35,128),(96,52,129),(97,35,130),(98,52,131),(99,52,132),(100,52,133),(101,61,134),(102,62,135),(103,62,136),(104,62,137),(105,62,138);
/*!40000 ALTER TABLE `group_meet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:24:04
