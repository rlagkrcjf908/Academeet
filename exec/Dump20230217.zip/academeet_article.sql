-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: academeet.shop    Database: academeet
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Auto Increment',
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(45) NOT NULL,
  `content` text NOT NULL,
  `file` text,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_User_TO_article_1` (`user_id`),
  KEY `FK_Group_TO_article_1` (`group_id`),
  CONSTRAINT `FK_Group_TO_article_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `FK_User_TO_article_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (7,24,9,'제목','  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos excepturi nemo animi, recusandae quae quos eligendi minima sint ab numquam suscipit tenetur voluptatum tempore, ut earum rem molestiae ipsum non.\n',NULL,'2023-02-12'),(8,25,9,'제목수정','내용\n  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis provident quaerat rem ut consequatur ad placeat eos aut necessitatibus unde aperiam, veritatis porro possimus dolor! Rerum velit at accusamus ipsam.\n  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis provident quaerat rem ut consequatur ad placeat eos aut necessitatibus unde aperiam, veritatis porro possimus dolor! Rerum velit at accusamus ipsam.\n  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis provident quaerat rem ut consequatur ad placeat eos aut necessitatibus unde aperiam, veritatis porro possimus dolor! Rerum velit at accusamus ipsam.\n  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis provident quaerat rem ut consequatur ad placeat eos aut necessitatibus unde aperiam, veritatis porro possimus dolor! Rerum velit at accusamus ipsam.\n',NULL,'2023-02-12'),(11,32,1033,'내가만든 그룹','내가 만든 그룹인데 멤버 조회할 때 내 정보가 안뜨네요\n껄껄',NULL,'2023-02-12'),(12,32,1033,'공지글','이 공지글이 다른사람한테도 보이면 좋겠네요.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n\n Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint accusamus ut repellat ipsam? Commodi, labore modi amet unde natus ipsam consequuntur dolorem laboriosam dignissimos assumenda nemo quis! Possimus, molestiae vero.\n',NULL,'2023-02-12'),(14,32,1033,'생각해보니','그룹 삭제 권한을 호스트에게만 줘야겠네요. 아무나 그룹을 삭제할 순 없으니..\n',NULL,'2023-02-12'),(15,33,1035,'학철','테스트',NULL,'2023-02-12'),(16,34,9,'테스트테스트','테스트테스트',NULL,'2023-02-12'),(17,36,1037,'test','test',NULL,'2023-02-13'),(18,35,1036,'프론트엔드 공지','내일 9시 30분에 스크럼회의해요~~~',NULL,'2023-02-13'),(19,35,1036,'벌써 마지막주라니','발표랑 UCC는 어떡하지?ㅠㅠㅠ',NULL,'2023-02-13'),(21,35,1036,'피곤해용','꿈의 나라로 떠나서 떠다니고 싶어요',NULL,'2023-02-13'),(22,35,1036,'소희야 안녕?','잠도 잘 못자고ㅠㅠ 많이 힘들지? 주어진 일에 열심인 소희 항상 응원해! 그로 인한 보람이 있을꺼야! 당장은 아니더라도 언젠가는 너에게 뒷받침 되어서 날개를 달 수 있을만한 성과를 이룰거라고 믿어 항상 힘내! \n\"소희를 항상 응원하고 지켜보는 누군가가\"',NULL,'2023-02-13'),(25,43,1033,'허허','나와랏',NULL,'2023-02-15'),(26,44,1036,'안녕하세요','안녕 나는 김소희',NULL,'2023-02-15'),(27,44,1036,'이상하다?','글을 썼는데 안불러와지네???',NULL,'2023-02-15'),(28,44,1036,'ㅇㅀㅇㄴㄹ','ㅁㅀㅇㅁ',NULL,'2023-02-15'),(29,47,1024,'공지사항','공지사항',NULL,'2023-02-15'),(30,35,1036,'ㅇㄴㄹㄴㅇㄹ','ㄴㅇㄹㄴㅇㄹㄴㅇㄴㅇ',NULL,'2023-02-15'),(31,52,1036,'Banker’s algorithm이란','프로세스가 자원을 요구할 때 시스템은 자원을 할당한 후에도 안정상태로 남아있게 되는지를 사전에 검사하여 교착 상태를 회피하는 기법입니다.\n\n시험에 나올 것 같으니 알아두면 좋을 것 같아요~',NULL,'2023-02-16'),(32,52,1024,'오늘 수업 관련 참고 자료 공유합니다','구글에 검색해 보시면 됩니다',NULL,'2023-02-16'),(33,52,1033,'5주차 우수교육생','투표 결과 이번 주 우수 교육생은 김소희 학생입니다!\n열심히 해 준 소희 학생 고마워요~\n\n다른 학생들도 수고 많았어요!',NULL,'2023-02-16'),(34,52,16,'Cocktail Sort에 대한 조사 자료 입니다.','쉐키라웃!',NULL,'2023-02-16'),(35,62,1041,'안녕하세요','안녕하세요 여러분들 김선생의 교실에 온것을 환영합니다!',NULL,'2023-02-17');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  1:24:04
